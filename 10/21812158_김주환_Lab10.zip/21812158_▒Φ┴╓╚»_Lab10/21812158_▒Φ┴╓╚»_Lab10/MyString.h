// MyString.h
#ifndef MS_H
#define MS_H
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void selectionSortWords(char** words, int num_words);
#endif