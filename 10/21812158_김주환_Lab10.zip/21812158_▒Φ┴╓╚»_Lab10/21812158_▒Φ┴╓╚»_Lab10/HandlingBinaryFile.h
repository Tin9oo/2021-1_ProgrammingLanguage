// HandlingBinaryFile.h
#ifndef HB_H
#define HB_H
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void dumpBinaryFile(FILE* fin, FILE* fout);
#endif