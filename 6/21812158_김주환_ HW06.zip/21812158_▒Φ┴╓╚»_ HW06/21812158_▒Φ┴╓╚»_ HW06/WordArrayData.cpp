// WordArrayData.cpp
#include "WordArray.h"

extern char words[MAX_NUM_WORDS][MAX_WORD_LEN] = {
	"double", "char", "auto", "default", "const", "continue", "break", "case", "do",
	"union", "unsigned", "void", "volatile", "while",
	"return", "short", "signed", "sizeof", "static", "struct", "switch", "typeof",
	"else", "enum", "extern", "float", "for", "goto", "if", "int","long", "register"
};