#ifndef BIG_ARRAY_H // ��� �ߺ� ����
#define BIG_ARRAY_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void printBigArraySample_double(double* dA, int size, int items_per_line, int num_sample_lines);
double* genBigRandArray_double(int bigRandSize, double offset);
void _hybridSort_QS_SS_double(double* array, int size, int left, int right);
void hybridSort_QS_SS_double(double* dA, int size);
#endif